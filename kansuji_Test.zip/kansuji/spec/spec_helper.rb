require './lib/kansuji'

RSpec.configure do |config|
end

